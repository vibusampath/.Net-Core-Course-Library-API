﻿using CourseLibrary_Common.Infrastructure.Constants;
using CourseLibrary_Provider;
using LenZ.Common.Constants;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;

namespace CourseLibrary.Api.Controllers
{
    [ApiController]
    [Route(Routes.Filters)]
    [TypeFilter(typeof(ApiExceptionFilter))]
    public class FiltersController : ControllerBase
    {
        private readonly FiltersProvider _filterController;

        public FiltersController()
        {
            _filterController = new FiltersProvider();
        }


        [HttpGet(Actions.Paging)]
        [SwaggerOperation(Summary = SwaggerSummary.Paging, Tags = new[] { SwaggerTag.Filter })]
        public async Task<IActionResult> Paging(int page)
        {
            return Ok(await _filterController.Paging(page));
        }


        [HttpGet(Actions.Sorting)]
        [SwaggerOperation(Summary = SwaggerSummary.Sorting, Tags = new[] { SwaggerTag.Filter })]
        public async Task<IActionResult> Sorting(string sort)
        {
            return Ok(await _filterController.Sorting(sort));
        }

    }
}
