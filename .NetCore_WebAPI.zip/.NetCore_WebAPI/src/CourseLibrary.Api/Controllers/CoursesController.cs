﻿using CourseLibrary_Common.Infrastructure.Constants;
using CourseLibrary_Model;
using CourseLibrary_Provider;
using LenZ.Common.Constants;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.Annotations;

namespace CourseLibrary.Api.Controllers
{
    [ApiController]
    [Route(Routes.Courses)]
    [TypeFilter(typeof(ApiExceptionFilter))]
    public class CoursesController : ControllerBase
    {
        private readonly CoursesProvider _coursesProvider;
        
        public CoursesController()
        {
            _coursesProvider = new CoursesProvider();
        }

        [HttpPost(Actions.CreateCourse)]
        [SwaggerOperation(Summary = SwaggerSummary.CreateCourse, Tags = new[] { SwaggerTag.Course })]
        public async Task<IActionResult> CreateCourse(Courses authors)
        {
            var result = await _coursesProvider.CreateCourse(authors);
            return Ok(result);

        }

        [HttpGet(Actions.ListCourseByAuthor)]
        [SwaggerOperation(Summary = SwaggerSummary.ListCourseByAuthor, Tags = new[] { SwaggerTag.Course })]
        public async Task<IActionResult> ListCourseByAuthor(int authorId)
        {
            var result = await _coursesProvider.ListCourseByAuthor(authorId);
            return Ok(result);

        }
             
        [HttpGet(Actions.GetCoursesById)]
        [SwaggerOperation(Summary = SwaggerSummary.GetCoursesById, Tags = new[] { SwaggerTag.Course })]
        public async Task<IActionResult> GetCoursesById(int coursesId)
        {
            return Ok(await _coursesProvider.GetCoursesById(coursesId));
        }

        [HttpPut(Actions.UpdateCourseAuthor)]
        [SwaggerOperation(Summary = SwaggerSummary.UpdateCourseAuthor, Tags = new[] { SwaggerTag.Course })]
        public async Task<IActionResult> UpdateCourseAuthor(Courses authors)
        {
            var result = await _coursesProvider.UpdateCourseAuthor(authors);
            return Ok(result);

        }

        // "op": "replace", "path": "title", "value": "Updated data"
        [HttpPatch(Actions.PartialUpdateCourse)]
        [SwaggerOperation(Summary = SwaggerSummary.PartialUpdateCourse, Tags = new[] { SwaggerTag.Course })]
        public async Task<IActionResult> PartialUpdateCourse([FromBody] JsonPatchDocument course, int authorId)
        {
            return Ok(await _coursesProvider.PartialUpdateCourse(course, authorId));
        }

        [HttpDelete(Actions.DeleteCourse)]
        [SwaggerOperation(Summary = SwaggerSummary.PartialUpdateCourse, Tags = new[] { SwaggerTag.Course })]
        public async Task<IActionResult> DeleteCourse(int coursesId,int authorId)
        {
            return Ok(await _coursesProvider.DeleteCourse(coursesId, authorId));
        }

    
    }
}
