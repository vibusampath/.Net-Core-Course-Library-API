﻿using CourseLibrary_Common.Infrastructure.Constants;
using CourseLibrary_Common.Infrastructure.EmailService;
using CourseLibrary_Model;
using CourseLibrary_Provider;
using LenZ.Common.Constants;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using Swashbuckle.AspNetCore.Annotations;
using System.Collections.Generic;

namespace CourseLibrary.Api.Controllers
{
    [ApiController]
    [Route(Routes.Authors)]
    [TypeFilter(typeof(ApiExceptionFilter))]
    public class AuthorsController : ControllerBase
    {
        private readonly AuthorsProvider _authorsProvider;
        public AuthorsController()
        {
            _authorsProvider = new AuthorsProvider();
        }

        [HttpGet(Actions.ListAuthors)]
        [SwaggerOperation(Summary = SwaggerSummary.ListAuthors, Tags = new[] { SwaggerTag.Author })]
        public async Task<IActionResult> ListAuthors()
        {
            return Ok(await _authorsProvider.ListAuthors());
        }

        [HttpPost(Actions.AddAuthor)]
        [SwaggerOperation(Summary = SwaggerSummary.AddAuthor, Tags = new[] { SwaggerTag.Author })]
        public async Task<IActionResult> AddAuthor(Authors author)
        {
            return Ok(await _authorsProvider.AddAuthor(author));
        }

        [HttpPost(Actions.CreateBatchAuthors)]
        [SwaggerOperation(Summary = SwaggerSummary.CreateBatchAuthors, Tags = new[] { SwaggerTag.Author })]
        public async Task<IActionResult> CreateBatchAuthors(List<Authors> authors)
        {
            return Ok(await _authorsProvider.CreateBatchAuthors(authors));
        }

        [HttpPost(Actions.GetBatchAuthorById)]
        [SwaggerOperation(Summary = SwaggerSummary.GetBatchAuthorById, Tags = new[] { SwaggerTag.Author })]
        public async Task<IActionResult> GetBatchAuthorById(List<GetAuthorId> authorIds)
        {
            return Ok(await _authorsProvider.GetBatchAuthorById(authorIds));
        }

    }
}
