﻿using CourseLibrary.LogWriter;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System.Net;

namespace LenZAPI.Infrastructure.ActionFilters
{
    public class ApiExceptionFilter : ExceptionFilterAttribute
    {
        public override void OnException(ExceptionContext context)
        {
            ResultObject result = new ResultObject();
            string message;

            if (context.Exception is UnauthorizedAccessException)
            {
                context.HttpContext.Response.StatusCode = (int)HttpStatusCode.Unauthorized;
                message = "Unauthorized Access";
            }
            else
            {
                message = string.IsNullOrWhiteSpace(context.Exception.Message) ? "Error" : context.Exception.Message;
                context.HttpContext.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
            }

            AppLogs.Logger.Error(context.Exception.ToString());
            result[ResultKey.Success] = false;
            result[ResultKey.Message] = message;
            context.Result = new JsonResult(result);

            base.OnException(context);
        }
    }
}
