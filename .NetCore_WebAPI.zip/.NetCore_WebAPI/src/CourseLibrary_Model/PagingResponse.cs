﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseLibrary_Model
{
    public class Filtering
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string DOB { get; set; }
        public string EmailId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }

    }
    public class PagingResponse
    {
        public List<Authors> Authors { get; set; } = new List<Authors>();
        public int CurrentPage { get; set; }
        public int Pages { get; set; }
    }
}
