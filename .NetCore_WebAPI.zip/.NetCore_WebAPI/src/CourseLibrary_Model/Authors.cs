﻿using Microsoft.VisualBasic;

namespace CourseLibrary_Model
{

    public class Authors
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string DOB { get; set; }
        public string EmailId { get; set; }

    }

    public class GetAuthorId
    {
        public string AuthorIds { get; set; }
    }


}