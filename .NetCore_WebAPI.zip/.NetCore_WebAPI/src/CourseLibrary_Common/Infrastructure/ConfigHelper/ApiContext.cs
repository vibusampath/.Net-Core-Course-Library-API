﻿using CourseLibrary_Model;
using Microsoft.EntityFrameworkCore;


public class ApiContext : DbContext
{
    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        optionsBuilder.UseInMemoryDatabase(databaseName: "AuthorDb");
    }
    public DbSet<Authors> Authors { get; set; }
    public DbSet<Courses> Courses { get; set; }

}
