﻿using Serilog;
using Serilog.Core;

namespace CourseLibrary.LogWriter
{
    public static class AppLogs
    {
        public static Logger Logger => new LoggerConfiguration()
            .WriteTo.File("Logs/log-.txt", rollingInterval: RollingInterval.Day)
            .CreateLogger();
    }
}
