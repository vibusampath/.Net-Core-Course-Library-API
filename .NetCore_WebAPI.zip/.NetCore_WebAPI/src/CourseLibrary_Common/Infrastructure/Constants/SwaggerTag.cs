﻿namespace LenZ.Common.Constants
{
    public static class SwaggerTag
    {
        public const string Author = "Author";
        public const string Course = "Course";
        public const string Filter = "Filter";
    }
}
