﻿
public static class Actions
{
    public const string ListAuthors = "ListAuthors";
    public const string AddAuthor = "AddAuthor";
    public const string CreateCourse = "CreateCourse";
    public const string ListCourseByAuthor = "ListCourseByAuthor";
    public const string GetCoursesById = "GetCoursesById";
    public const string UpdateCourseAuthor = "UpdateCourseAuthor";
    public const string PartialUpdateCourse = "PartialUpdateCourse";
    public const string DeleteCourse = "DeleteCourse";
    public const string CreateBatchAuthors = "SaveBatchAuthors";
    public const string GetBatchAuthorById = "GetBatchAuthorById";
    public const string Paging = "Paging";
    public const string Sorting = "Sorting";

}
