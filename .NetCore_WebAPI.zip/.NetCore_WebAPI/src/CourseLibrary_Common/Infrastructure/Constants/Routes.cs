﻿
public static class Routes
{
    public const string Authors = "Authors";
    public const string Courses = "Courses";
    public const string Filters = "Filters";

}
