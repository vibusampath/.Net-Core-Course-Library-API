﻿
public static class ResultKey
{
    public const string Success = "Success";
    public const string Message = "Message";
    public const string Data = "Data";
    public const string Error = "Error";
}
public static class Message
{
    public const string Success = "Success";
    public const string Failed = "Failed";
}
