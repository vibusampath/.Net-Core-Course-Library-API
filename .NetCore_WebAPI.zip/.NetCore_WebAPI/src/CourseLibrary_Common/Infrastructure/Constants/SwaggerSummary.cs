﻿using System;

namespace CourseLibrary_Common.Infrastructure.Constants
{
    public static class SwaggerSummary
    {
        public const string ListAuthors = "List all authors";
        public const string AddAuthor = "Add a new author";
        public const string CreateCourse = "Create courses for an author";
        public const string ListCourseByAuthor = "List all courses for an author";
        public const string GetCoursesById = "Get one course for an author by the course identifier";
        public const string UpdateCourseAuthor = "Update course for an author";
        public const string PartialUpdateCourse = "Partially update course for an author using patch request";
        public const string DeleteCourse = "Delete course for an author";
        public const string CreateBatchAuthors = "Create a batch of authors using a single endpoint";
        public const string GetBatchAuthorById = "Get a batch of authors corresponding to multiple author identifiers passed as parameter to an endpoint";
        public const string Paging = "Implement paging for all endpoints that return multiple results";
        public const string Sorting = "Implement sorting(by name for authors and by title for courses) for all endpoints that return multiple results";
    }
}
