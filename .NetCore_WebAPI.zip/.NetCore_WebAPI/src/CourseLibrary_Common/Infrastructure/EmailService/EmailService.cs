﻿using CourseLibrary.LogWriter;
using System.Net;
using System.Net.Mail;

namespace CourseLibrary_Common.Infrastructure.EmailService
{
    public class MailClient
    {
        public string HostAddress { get; set; }
        public int Port { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }

        public async Task<bool> SendMailAsync(string emailAddress, string subject, string message)
        {
            bool result = false;

            MailMessage mail = new MailMessage
            {
                Subject = subject,
                IsBodyHtml = true,
                Body = "Course Title : " + message
            };

            mail.From = new MailAddress(UserName);
            mail.To.Add(emailAddress);

            SmtpClient smtp = new SmtpClient
            {
                Host = HostAddress,
                Port = Port,
                Credentials = new NetworkCredential(UserName, Password),
                EnableSsl = true
            };

            smtp.SendCompleted += (s, e) =>
            {
                smtp.Dispose();
                mail.Dispose();
            };

            await smtp.SendMailAsync(mail);
            result = true;

            return result;
        }
    }
}
