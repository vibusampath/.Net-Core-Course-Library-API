﻿using CourseLibrary_Model;

namespace CourseLibrary.Interface
{
    public interface IAuthorRepository
    {
        Task<IList<Authors>> ListAuthors();
        Task<Authors> GetAuthorById(int authorsId);
        Task<bool> AddAuthor(Authors author);
        Task<bool> CreateBatchAuthors(List<Authors> authors);
        Task<IList<Authors>> GetBatchAuthorById(List<GetAuthorId> authorIds);

    }
}
