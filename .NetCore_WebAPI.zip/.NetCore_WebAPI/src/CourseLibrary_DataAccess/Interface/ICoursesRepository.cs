﻿using CourseLibrary_Model;
using Microsoft.AspNetCore.JsonPatch;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseLibrary.Interface
{
    public interface ICoursesRepository
    {
        Task<bool> CreateCourse(Courses authors);
        Task<IList<Courses>> ListCourseByAuthor(int authorsId);
        Task<Courses> GetCoursesById(int coursesId);
        Task<bool> DeleteCourse(int coursesId, int authorId);
        Task<bool> UpdateCourseAuthor(Courses authors);
        Task<bool> PartialUpdateCourse(JsonPatchDocument coursesId, int authorId);
    }
}
