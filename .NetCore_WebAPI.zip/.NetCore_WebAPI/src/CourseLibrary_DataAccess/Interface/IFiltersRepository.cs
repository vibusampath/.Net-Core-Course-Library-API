﻿using CourseLibrary_Model;

namespace CourseLibrary.Interface
{
    public interface IFiltersRepository
    {
        Task<IList<PagingResponse>> Paging(int page);
        Task<IEnumerable<dynamic>> Sorting(string sort);
        
    }
}
