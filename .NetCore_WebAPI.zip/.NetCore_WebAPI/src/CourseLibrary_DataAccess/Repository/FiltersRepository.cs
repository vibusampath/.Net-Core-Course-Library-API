﻿using CourseLibrary.Interface;
using CourseLibrary_Model;
using Microsoft.EntityFrameworkCore;

namespace CourseLibrary.Repository
{
    public class FiltersRepository : IFiltersRepository
    {
        private readonly ApiContext _context;

        public FiltersRepository()
        {
            _context = new ApiContext();
        }

        public async Task<IList<PagingResponse>> Paging(int page)
        {
            List<PagingResponse> lstPaging = new();
            if (_context.Authors != null)
            {

                var author = await _context.Authors.ToListAsync();
                var pageresult = 3f;
                var pageCount = Math.Ceiling(author.Count() / pageresult);

                var product = await _context.Authors.Skip((page - 1) * (int)pageresult).Take((int)pageresult).ToListAsync();

                var response = new PagingResponse
                {
                    Authors = product,
                    CurrentPage = page,
                    Pages = Convert.ToInt32(pageCount)

                };

                lstPaging.Add(response);
                return lstPaging;
            }
            else
            {
                return lstPaging;
            }
        }

        public async Task<IEnumerable<dynamic>> Sorting(string sort)
        {
            dynamic SortingResult = "";
            if (_context.Authors != null && _context.Courses != null)
            {
                if (sort.ToLower() == "asc")
                {
                    SortingResult = (from author in _context.Authors.OrderBy(c => c.FirstName)
                                     join course in _context.Courses.OrderBy(c => c.Title) on author.Id equals course.AuthorId
                                     orderby course.AuthorId
                                     select new
                                     {
                                         author.FirstName,
                                         author.LastName,
                                         author.DOB,
                                         author.EmailId,
                                         course.Title,
                                         course.Description
                                     }).ToList();
                }
                else
                {
                    SortingResult = (from author in _context.Authors.OrderByDescending(c => c.FirstName)
                                     join course in _context.Courses.OrderByDescending(c => c.Title) on author.Id equals course.AuthorId
                                     orderby course.AuthorId
                                     select new
                                     {
                                         author.FirstName,
                                         author.LastName,
                                         author.DOB,
                                         author.EmailId,
                                         course.Title,
                                         course.Description
                                     }).ToList();
                }

            }

            return SortingResult;
        }

    }
}
