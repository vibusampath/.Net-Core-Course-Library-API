﻿using CourseLibrary.Interface;
using CourseLibrary_Common.Infrastructure.EmailService;
using CourseLibrary_Model;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.SignalR.Protocol;
using Microsoft.EntityFrameworkCore;
using Org.BouncyCastle.Math.EC.Rfc7748;
using System.Collections.Generic;

namespace CourseLibrary.Repository
{
    public class CoursesRepository : ICoursesRepository
    {
        private readonly ApiContext _context;

        public CoursesRepository()
        {
            _context = new ApiContext();

        }

        public async Task<bool> CreateCourse(Courses courses)
        {
            var authorEmail = await _context.Authors.Where(x => x.Id == courses.AuthorId).SingleOrDefaultAsync();
            if (authorEmail != null)
            {
                var course = await _context.Courses.Where(x => x.Id == courses.Id).SingleOrDefaultAsync();
                if (course == null)
                {
                    _context.Courses.Add(courses);

                    MailClient mailClient = new()
                    {
                        Port = 587,
                        HostAddress = "smtp.gmail.com",
                        UserName = "vibusampath38@gmail.com",
                        Password = "nzevntxoutumvvqb"
                    };

                    await mailClient.SendMailAsync(authorEmail.EmailId, "Author Add New Course", courses.Title);

                }
                else
                {
                    course.Title = courses.Title;
                    course.Description = courses.Description;
                }
            }
            return await _context.SaveChangesAsync() > 0;
        }

        public async Task<IList<Courses>> ListCourseByAuthor(int authorsId)
        {
            IList<Courses> lstCourses = await _context.Courses.Where(x => x.AuthorId == authorsId).ToListAsync();
            return lstCourses;
        }

        public async Task<Courses> GetCoursesById(int courseId)
        {
            var courses = await _context.Courses.FindAsync(courseId);
            if (courses == null)
            {
                Courses obj = new();
                return obj;
            }
            return courses;
        }

        public async Task<bool> UpdateCourseAuthor(Courses courses)
        {

            var course = await _context.Courses.Where(x => x.Id == courses.Id).SingleOrDefaultAsync();
            if (course != null)
            {
                course.Title = courses.Title;
                course.Description = courses.Description;
            }

            return await _context.SaveChangesAsync() > 0;
        }

        public async Task<bool> PartialUpdateCourse(JsonPatchDocument course, int authorId)
        {

            var result = await _context.Courses.FindAsync(authorId);
            if (result != null)
            {
                course.ApplyTo(result);
            }
            return await _context.SaveChangesAsync() > 0;

        }

        public async Task<bool> DeleteCourse(int coursesId, int authorId)
        {
            var result = await _context.Courses.Where(x => x.Id == coursesId && x.AuthorId == authorId).SingleOrDefaultAsync();
            if (result == null)
            {
                return false;
            }
            _context.Courses.Remove(result);
            return await _context.SaveChangesAsync() > 0;

        }


    }
}
