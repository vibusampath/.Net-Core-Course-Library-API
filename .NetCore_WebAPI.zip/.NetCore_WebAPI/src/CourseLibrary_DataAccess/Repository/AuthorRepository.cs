﻿using CourseLibrary.Interface;
using CourseLibrary_Model;
using Microsoft.EntityFrameworkCore;

namespace CourseLibrary.Repository
{
    public class AuthorRepository : IAuthorRepository
    {
        private readonly ApiContext _context;

        public AuthorRepository()
        {
            _context = new ApiContext();
        }

        public async Task<IList<Authors>> ListAuthors()
        {
            IList<Authors> lstAuthors = await _context.Authors.ToListAsync();
            return lstAuthors;
        }

        public async Task<Authors> GetAuthorById(int authorsId)
        {
            var authors = await _context.Authors.FindAsync(authorsId);
            if (authors == null)
            {
                Authors obj = new();
                return obj;
            }
            return authors;
        }

        public async Task<bool> AddAuthor(Authors author)
        {
            var user = await _context.Authors.Where(x => x.Id == author.Id).SingleOrDefaultAsync();
            if (user == null)
            {
                _context.Authors.Add(author);
            }
            else
            {
                user.FirstName = author.FirstName;
                user.LastName = author.LastName;
                user.DOB = author.DOB;
                user.EmailId = author.EmailId;
            }
            return await _context.SaveChangesAsync() > 0;
        }

        public async Task<bool> CreateBatchAuthors(List<Authors> authors)
        {
            foreach (Authors lstauthor in authors)
            {
                _context.Authors.Add(lstauthor);
            }

            return await _context.SaveChangesAsync() > 0;
        }

        public async Task<IList<Authors>> GetBatchAuthorById(List<GetAuthorId> authorIds)
        {
            //dynamic jsonObj = JsonConvert.DeserializeObject(authorIds.ToString());
            List<Authors> lstAuthors = new();
            foreach (var item in authorIds)
            {
                var result = await _context.Authors.Where(x => x.Id == Convert.ToInt32(item.AuthorIds)).SingleOrDefaultAsync();
                lstAuthors.Add(result);

            }
            return lstAuthors;
        }
      
    }
}
