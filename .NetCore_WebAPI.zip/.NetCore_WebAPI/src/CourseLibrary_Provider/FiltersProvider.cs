﻿using AutoMapper;
using CourseLibrary.Interface;
using CourseLibrary.Repository;
using CourseLibrary_Common.Infrastructure.EmailService;
using CourseLibrary_Model;
using Newtonsoft.Json.Linq;

namespace CourseLibrary_Provider
{
    public class FiltersProvider
    {
        private readonly FiltersRepository _filtersRepository;

        private readonly ResultObject _result;
        public FiltersProvider()
        {
            _filtersRepository = new FiltersRepository();
            _result = new ResultObject();

        }

        public async Task<ResultObject> Paging(int page)
        {
            _result[ResultKey.Success] = true;
            _result[ResultKey.Data] = await _filtersRepository.Paging(page);
            return _result;

        }

        public async Task<ResultObject> Sorting(string sort)
        {
            _result[ResultKey.Success] = true;
            _result[ResultKey.Data] = await _filtersRepository.Sorting(sort);
            return _result; 


        }
    }
}