﻿using AutoMapper;
using CourseLibrary.Interface;
using CourseLibrary.Repository;
using CourseLibrary_Common.Infrastructure.EmailService;
using CourseLibrary_Model;
using Newtonsoft.Json.Linq;

namespace CourseLibrary_Provider
{
    public class AuthorsProvider
    {
        private readonly AuthorRepository _authorRepository;

        private readonly ResultObject _result;

        public AuthorsProvider()
        {
            _authorRepository = new AuthorRepository();
            _result = new ResultObject();

        }

        public async Task<ResultObject> ListAuthors()
        {
            _result[ResultKey.Success] = true;
            _result[ResultKey.Data] = await _authorRepository.ListAuthors();
            return _result;

        }

        public async Task<ResultObject> GetAuthorById(int authorsId)
        {
            _result[ResultKey.Success] = true;
            _result[ResultKey.Data] = await _authorRepository.GetAuthorById(authorsId);
            return _result;

        }

        public async Task<ResultObject> AddAuthor(Authors author)
        {

            if (author != null)
            {

                if (await _authorRepository.AddAuthor(author))
                {

                    _result[ResultKey.Success] = true;
                    _result[ResultKey.Message] = Message.Success;
                }
            }
            else
            {
                _result[ResultKey.Success] = false;
                _result[ResultKey.Message] = Message.Failed;
            }

            return _result;
        }

        public async Task<ResultObject> CreateBatchAuthors(List<Authors> authors)
        {
            if (authors != null && authors.Count > 0)
            {

                if (await _authorRepository.CreateBatchAuthors(authors))
                {
                    _result[ResultKey.Success] = true;
                    _result[ResultKey.Message] = Message.Success;
                }
            }
            else
            {
                _result[ResultKey.Success] = false;
                _result[ResultKey.Message] = Message.Failed;
            }

            return _result;
        }

        public async Task<ResultObject> GetBatchAuthorById(List<GetAuthorId> authorIds)
        {
            _result[ResultKey.Success] = true;
            _result[ResultKey.Data] = await _authorRepository.GetBatchAuthorById(authorIds);
            return _result;

        }

    }
}