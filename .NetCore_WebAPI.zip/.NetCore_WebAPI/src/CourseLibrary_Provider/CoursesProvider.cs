﻿using CourseLibrary.Interface;
using CourseLibrary.Repository;
using CourseLibrary_Common.Infrastructure.EmailService;
using CourseLibrary_Model;
using Microsoft.AspNetCore.JsonPatch;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CourseLibrary_Provider
{
    public class CoursesProvider
    {
        private readonly CoursesRepository _coursesRepository;

        private readonly ResultObject _result;
        public CoursesProvider()
        {
            _coursesRepository = new CoursesRepository();
            _result = new ResultObject();

        }

        public async Task<ResultObject> CreateCourse(Courses courses)
        {
            if (courses != null)
            {

                if (await _coursesRepository.CreateCourse(courses))
                {
                    _result[ResultKey.Success] = true;
                    _result[ResultKey.Message] = Message.Success;
                }
                else
                {
                    _result[ResultKey.Success] = false;
                    _result[ResultKey.Message] = "Please Create author for an Course";
                }
            }
            else
            {
                _result[ResultKey.Success] = false;
                _result[ResultKey.Message] = Message.Failed;
            }

            return _result;
        }

        public async Task<ResultObject> ListCourseByAuthor(int authorId)
        {
            if (authorId > 0)
            {
                _result[ResultKey.Success] = true;
                _result[ResultKey.Data] = await _coursesRepository.ListCourseByAuthor(authorId);
            }

            else
            {
                _result[ResultKey.Success] = false;
                _result[ResultKey.Message] = Message.Failed;
            }

            return _result;
        }

        public async Task<ResultObject> GetCoursesById(int coursesId)
        {
            _result[ResultKey.Success] = true;
            _result[ResultKey.Data] = await _coursesRepository.GetCoursesById(coursesId);
            return _result;

        }

        public async Task<ResultObject> UpdateCourseAuthor(Courses courses)
        {
            if (courses != null)
            {

                if (await _coursesRepository.CreateCourse(courses))
                {
                    _result[ResultKey.Success] = true;
                    _result[ResultKey.Message] = Message.Success;
                }
                else
                {
                    _result[ResultKey.Success] = false;
                    _result[ResultKey.Message] = "Course not available.";
                }
            }
            else
            {
                _result[ResultKey.Success] = false;
                _result[ResultKey.Message] = Message.Failed;
            }

            return _result;
        }

        public async Task<ResultObject> PartialUpdateCourse(JsonPatchDocument course, int authorId)
        {

            if (authorId > 0)
            {

                if (await _coursesRepository.PartialUpdateCourse(course, authorId))
                {
                    _result[ResultKey.Success] = true;
                    _result[ResultKey.Message] = Message.Success;

                }
                else
                {
                    _result[ResultKey.Success] = false;
                    _result[ResultKey.Message] = Message.Failed;
                }
            }

            return _result;
        }

        public async Task<ResultObject> DeleteCourse(int coursesId, int authorId)
        {

            if (coursesId > 0 && authorId > 0)
            {

                if (await _coursesRepository.DeleteCourse(coursesId, authorId))
                {
                    _result[ResultKey.Success] = true;
                    _result[ResultKey.Message] = Message.Success;

                }
                else
                {
                    _result[ResultKey.Success] = false;
                    _result[ResultKey.Message] = Message.Failed;
                }
            }

            return _result;
        }

    }
}
